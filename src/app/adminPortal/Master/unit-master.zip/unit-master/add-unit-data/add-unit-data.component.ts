import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
//import  'rxjs/add/operator/toPromise';


@Component({
  selector: 'app-add-unit-data',
  templateUrl: './add-unit-data.component.html',
  styleUrls: ['./add-unit-data.component.css']
})
export class AddUnitDataComponent implements OnInit {

  constructor(private http: Http) { }
  id:number;
  private headers=new Headers({'Content-Type':'application/json'});
products=[];
  confermationString:string="New unit data has been added successfully...!";
  isAdded: boolean=false;
  addDataobj : object={};
  addNewUnitData=function(product)
  {
    this.addDataobj = {
      "unitName" : product.unitName,
      "unitDescription": product.unitDescription
    }
    this.http.post("http://localhost:64597/api/unitMaster", this.addDataobj).subscribe((res:Response)=>{
      this.isAdded = true;
  })
  }
deleteUnitData=function(){
if(confirm("ARE YOU SURE")){
  const url='$("http://localhost:64597/api/unitMaster")/${id}';
  return this.http.delete(url,{headers:this.headers}).toPromise().then (()=>{
    this.addNewUnitData();
  })

}}   
  ngOnInit() {
  }

} 